<?php
//
include ("library/checklogin.php");
    $operator = $_SESSION['operator_user'];

        include_once('library/config_read.php');
    $log = "visited page: ";
        $m_active = "info";

?>
<?php
include_once('library/config_read.php');
include 'library/opendb.php';
//检查用户
function check_username_pwd($username, $pwd){
   global $dbSocket;
   global $configValues;
    $query_sql = "SELECT * FROM ".$configValues['CONFIG_DB_TBL_RADCHECK']." WHERE username = '$username'";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
          $db_username = $row[1];
          $db_attribute = $row[2];
          $db_op = $row[3];
          $db_value = $row[4];
          if ($username == $db_username){
              if ($db_attribute == 'Cleartext-Password' || $db_attribute == 'User-Password'){
                  if ($db_value == $pwd)
                      return true;
              }

          }

        }else{
        return false;
    }

}
//获取流量
function get_user_used_traffic($username){
   global $dbSocket;
   global $configValues;
    $query_sql = "SELECT SUM(acctinputoctets + acctoutputoctets) FROM ".$configValues['CONFIG_DB_TBL_RADACCT']." WHERE username = '$username';";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
        if ($row[0] <> ''){
                return $row[0];
        }else{
                return 0;
        }
    }else{
        return false;
    }
}
//
function get_user_used_days($username){
   global $dbSocket;
   global $configValues;
    $query_sql = "SELECT IF(COUNT(radacctid>=1),(UNIX_TIMESTAMP() - IFNULL(UNIX_TIMESTAMP(AcctStartTime),0)),0) DIV 86400 FROM ".$configValues['CONFIG_DB_TBL_RADACCT']." WHERE username = '$username' AND AcctSessionTime >= 1 ORDER BY AcctStartTime LIMIT 1";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
        return $row[0];
    }else{
        return false;
    }

}
//
function get_user_total_traffic($username){
   global $dbSocket;
   global $configValues;
    $max_global_traffic = 0;
    $max_active_days = 0;
    $query_sql = "SELECT groupname FROM ".$configValues['CONFIG_DB_TBL_RADUSERGROUP']." WHERE username = '$username'";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
        $groupname = $row[0];
          $query_sql1 = "SELECT * FROM ".$configValues['CONFIG_DB_TBL_RADGROUPCHECK']." WHERE groupname = '$groupname'";
          $re1=$dbSocket->query($query_sql1);
          while($row1=$re1->fetchRow()){
              if ("Max-Global-Traffic" == $row1[2]){
                  $max_global_traffic = $row1[4];
              }elseif("Max-Active-Days" == $row1[2]){
                  $max_active_days = $row1[4];
              }
          }

    }
    $max=array();
    $max[0]=$max_global_traffic;
    $max[1]=$max_active_days;
    return $max;

}
//主程序

	$dbSocket->query("truncate radpostauth;");

	$query_sql = "select * from radcheck;";
	$re = $dbSocket->query($query_sql);
	while($row=$re->fetchRow())
	{
		$db_username = $row[1];
		$cur_traffic = get_user_used_traffic($db_username);
		$activeDaysCount =get_user_used_days($db_username);
		
		if ($cur_traffic == 0 || $activeDaysCount == 0)
		{
			continue;
		}
		$umax = get_user_total_traffic($db_username);
		
		
		$max_global_traffic=$umax[0]*1024*1024;
		$max_active_days=$umax[1];

		
		
		//跳过无限制用户
		if ($max_global_traffic == 0 && $max_active_days == 0)
		{
			continue;
		}
		
		//天数用尽
		if ($max_active_days <= $activeDaysCount && $max_active_days != 0)
		{
			echo "已清空当前账号--天数用尽：".$db_username."-[username]-".$max_global_traffic."-[max tr]-".$max_active_days."-[max day]-".$cur_traffic."-[cur tr]-".$activeDaysCount."[cur day]<br>";
			$dbSocket->query("delete FROM radusergroup where username = '$db_username'");
			$dbSocket->query("delete FROM radcheck where username = '$db_username'");
			$dbSocket->query("delete FROM radacct where username = '$db_username'");
			continue;
		}
	
		//流量用尽
		if ($max_global_traffic <= $cur_traffic && $max_global_traffic != 0)
		{
			echo "已清空当前账号--流量用尽: ".$db_username."-[username]-".$max_global_traffic."-[max tr]-".$max_active_days."-[max day]-".$cur_traffic."-[cur tr]-".$activeDaysCount."[cur day]<br>";
			$dbSocket->query("delete FROM radusergroup where username = '$db_username'");
			$dbSocket->query("delete FROM radcheck where username = '$db_username'");
			$dbSocket->query("delete FROM radacct where username = '$db_username'");
			continue;
		}
	}
	
	echo "----------------------------已完成一键清理，感谢您的使用！！！----------------------------<br>";
	echo "----------------------------已完成一键清理，感谢您的使用！！！----------------------------<br>";
	
	
	
	
	echo "                                                                                          <br>";
	echo "                    提示:若上方没有出现账号则说明当前没有过期卡密                       <br>";
	echo "                                                                                          <br>";
echo "<script>alert('过期用户清理完成')</script>";
echo "<script>history.go(-1);</script>";
?>
