<?php
//
include ("library/checklogin.php");
    $operator = $_SESSION['operator_user'];

        include_once('library/config_read.php');
    $log = "visited page: ";
        $m_active = "info";

?>
<?php  
$conn=mysql_connect('localhost','radius','hehe123');
mysql_db_query("radius", "reset query cache", $conn);
echo "<script>alert('数据缓存清理完成')</script>";
echo "<script>history.go(-1);</script>";
?> 